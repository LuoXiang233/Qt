#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <math.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    digitBTNs = {{Qt::Key_0, ui->btnNum0},
               {Qt::Key_1, ui->btnNum1},
               {Qt::Key_2, ui->btnNum2},
               {Qt::Key_3, ui->btnNum3},
               {Qt::Key_4, ui->btnNum4},
               {Qt::Key_5, ui->btnNum5},
               {Qt::Key_6, ui->btnNum6},
               {Qt::Key_7, ui->btnNum7},
               {Qt::Key_8, ui->btnNum8},
               {Qt::Key_9, ui->btnNum9},
               };

    foreach(auto btn,digitBTNs)
        connect(btn,SIGNAL(clicked()), this, SLOT(btnNumClicked()));

    connect(ui->btnMultiple,SIGNAL(clicked()), this, SLOT(btnBinaryOperatorClicked()));
    connect(ui->btnPlus,SIGNAL(clicked()), this, SLOT(btnBinaryOperatorClicked()));
    connect(ui->btnMinus,SIGNAL(clicked()), this, SLOT(btnBinaryOperatorClicked()));
    connect(ui->btnDivide,SIGNAL(clicked()), this, SLOT(btnBinaryOperatorClicked()));

    connect(ui->btnPercentage,SIGNAL(clicked()), this, SLOT(btnUnaryOperatorClicked()));
    connect(ui->btnInverse,SIGNAL(clicked()), this, SLOT(btnUnaryOperatorClicked()));
    connect(ui->btnSquare,SIGNAL(clicked()), this, SLOT(btnUnaryOperatorClicked()));
    connect(ui->btnSqrt,SIGNAL(clicked()), this, SLOT(btnUnaryOperatorClicked()));
    connect(ui->btnSign, SIGNAL(clicked()), this, SLOT(btnUnaryOperatorClicked()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

QString MainWindow::calculation(bool *ok)
{
    double result = 0;
    bool success = true;

    while (operands.size() >= 2 && !opcodes.isEmpty()) {
        double operand1 = operands.front().toDouble();
        operands.pop_front();
        double operand2 = operands.front().toDouble();
        operands.pop_front();

        QString op = opcodes.front();
        opcodes.pop_front();


        if (op == "+") {
            result = operand1 + operand2;
        } else if (op == "-") {
            result = operand1 - operand2;
        } else if (op == "×" || op == "*") {
            result = operand1 * operand2;
        } else if (op == "/") {
            if (operand2 == 0) {
                success = false;
                ui->statusbar->showMessage("错误：除数不能为0");
                if (ok) *ok = success;
                return "Error";
            }
            result = operand1 / operand2;
        } else {
            success = false;
            ui->statusbar->showMessage("未知运算符：" + op);
            if (ok) *ok = success;
            return "Error";
        }

        operands.push_front(QString::number(result));
        ui->statusbar->showMessage(QString("计算：%1 %2 %3 = %4").arg(operand1).arg(op).arg(operand2).arg(result));
    }

    if (operands.size() == 1) {
        result = operands.front().toDouble();
    } else if (operands.isEmpty() && opcodes.isEmpty()) {
        result = 0;
    } else {
        success = false;
        ui->statusbar->showMessage("错误：操作数不足");
    }

    if (ok) *ok = success;
    return QString::number(result);
}

void MainWindow::btnNumClicked()
{
    QString digit = qobject_cast<QPushButton *>(sender())->text();

    if(digit == "0" && operand == "0") digit ="";
    if(operand == "0" && digit !="0") operand = "";



    operand += digit;

    ui->display->setText(operand);
}

void MainWindow::btnBinaryOperatorClicked()
{
    QString opcode = qobject_cast<QPushButton *>(sender())->text();

    if (operand.isEmpty()) {
        if (!opcodes.isEmpty()) {
            opcodes.pop_back();
            opcodes.push_back(opcode);
        }
        return;
    }

    operands.push_back(operand);
    operand.clear();
    if (opcodes.size() >= 1 && operands.size() >= 2) {
        calculation();
    }

    opcodes.push_back(opcode);

    if (!operands.isEmpty()) {
        ui->display->setText(operands.back());
    }
}

void MainWindow::btnUnaryOperatorClicked()
{
    if(operand != ""){
        double result = operand.toDouble();
        operand = "";

        QString op = qobject_cast<QPushButton*>(sender())->text();

        if(op == "%"){
            result /= 100.0;
        }else if(op == "1/x"){
            result = 1/result;
        }else if(op == "x^2"){
            result *= result;
        }else if(op == "√"){
            if(result < 0) {
                ui->display->setText("Error");
                return;
            }
            result = sqrt(result);
        }else if(op == "+/-"){
            result = -result;
        }

        ui->display->setText(QString::number(result));
        operand = QString::number(result);
    } else if(!operands.isEmpty()) {
        double result = operands.top().toDouble();
        operands.pop();
        result = -result;
        operands.push(QString::number(result));
        ui->display->setText(QString::number(result));
        operand = QString::number(result);
    }
}

void MainWindow::on_btnPeriod_clicked()
{

    if(!operand.contains("."))
        operand += qobject_cast<QPushButton *>(sender())->text();
     ui->display->setText(operand);
}


void MainWindow::on_btnDel_clicked()
{
    if(!operand.isEmpty()){
        operand = operand.left(operand.length() - 1);
        ui->display->setText(operand);
    }
}

void MainWindow::on_btnClear_clicked()
{
    operand.clear();
    operands.clear();
    opcodes.clear();
    ui->display->setText("0");
}

void MainWindow::on_btnEqual_clicked()
{
    if (!operand.isEmpty()) {
        operands.push_back(operand);
        operand.clear();
    }

    bool ok;
    QString result = calculation(&ok);

    if (ok) {
        ui->display->setText(result);

        operand = result;
        operands.clear();
        opcodes.clear();
    } else {
        ui->display->setText("Error");
        operand.clear();
        operands.clear();
        opcodes.clear();
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    foreach(auto btnKey, digitBTNs.keys()){
        if(event->key() == btnKey)
            digitBTNs[btnKey]->animateClick();
    }

    switch(event->key()){
    case Qt::Key_Plus: ui->btnPlus->animateClick(); break;
    case Qt::Key_Minus: ui->btnMinus->animateClick(); break;
    case Qt::Key_Asterisk: ui->btnMultiple->animateClick(); break;
    case Qt::Key_Slash: ui->btnDivide->animateClick(); break;
    case Qt::Key_Enter:
    case Qt::Key_Return: ui->btnEqual->animateClick(); break;
    case Qt::Key_Backspace: ui->btnDel->animateClick(); break;
    case Qt::Key_Period:
    case Qt::Key_Comma:
        ui->btnPeriod->animateClick();
        break;
    }
}
void MainWindow::on_btnSign_clicked()
{

}
